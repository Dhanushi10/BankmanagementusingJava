<?xml version="1.0" encoding="UTF-8" ?>

<Form version="1.5" maxVersion="1.9" type="org.netbeans.modules.form.forminfo.JInternalFrameFormInfo">
  <SyntheticProperties>
    <SyntheticProperty name="formSizePolicy" type="int" value="1"/>
  </SyntheticProperties>
  <AuxValues>
    <AuxValue name="FormSettings_autoResourcing" type="java.lang.Integer" value="0"/>
    <AuxValue name="FormSettings_autoSetComponentName" type="java.lang.Boolean" value="false"/>
    <AuxValue name="FormSettings_generateFQN" type="java.lang.Boolean" value="true"/>
    <AuxValue name="FormSettings_generateMnemonicsCode" type="java.lang.Boolean" value="false"/>
    <AuxValue name="FormSettings_i18nAutoMode" type="java.lang.Boolean" value="false"/>
    <AuxValue name="FormSettings_layoutCodeTarget" type="java.lang.Integer" value="1"/>
    <AuxValue name="FormSettings_listenerGenerationStyle" type="java.lang.Integer" value="0"/>
    <AuxValue name="FormSettings_variablesLocal" type="java.lang.Boolean" value="false"/>
    <AuxValue name="FormSettings_variablesModifier" type="java.lang.Integer" value="2"/>
  </AuxValues>

  <Layout>
    <DimensionLayout dim="0">
      <Group type="103" groupAlignment="0" attributes="0">
          <Group type="102" alignment="0" attributes="0">
              <EmptySpace min="-2" pref="34" max="-2" attributes="0"/>
              <Group type="103" groupAlignment="0" attributes="0">
                  <Component id="jLabel5" min="-2" max="-2" attributes="0"/>
                  <Component id="jPanel3" min="-2" max="-2" attributes="0"/>
              </Group>
              <EmptySpace pref="26" max="32767" attributes="0"/>
          </Group>
      </Group>
    </DimensionLayout>
    <DimensionLayout dim="1">
      <Group type="103" groupAlignment="0" attributes="0">
          <Group type="102" alignment="0" attributes="0">
              <EmptySpace min="-2" pref="29" max="-2" attributes="0"/>
              <Component id="jLabel5" min="-2" max="-2" attributes="0"/>
              <EmptySpace type="unrelated" max="-2" attributes="0"/>
              <Component id="jPanel3" min="-2" max="-2" attributes="0"/>
              <EmptySpace pref="58" max="32767" attributes="0"/>
          </Group>
      </Group>
    </DimensionLayout>
  </Layout>
  <SubComponents>
    <Component class="javax.swing.JLabel" name="jLabel5">
      <Properties>
        <Property name="font" type="java.awt.Font" editor="org.netbeans.beaninfo.editors.FontEditor">
          <Font name="Tahoma" size="24" style="1"/>
        </Property>
        <Property name="text" type="java.lang.String" value="Users"/>
      </Properties>
    </Component>
    <Container class="javax.swing.JPanel" name="jPanel3">

      <Layout>
        <DimensionLayout dim="0">
          <Group type="103" groupAlignment="0" attributes="0">
              <Group type="102" alignment="0" attributes="0">
                  <EmptySpace max="-2" attributes="0"/>
                  <Group type="103" groupAlignment="0" attributes="0">
                      <Group type="102" attributes="0">
                          <Group type="103" groupAlignment="0" attributes="0">
                              <Component id="jLabel6" alignment="0" min="-2" max="-2" attributes="0"/>
                              <Component id="jLabel8" alignment="0" min="-2" max="-2" attributes="0"/>
                              <Component id="jLabel11" alignment="0" min="-2" max="-2" attributes="0"/>
                          </Group>
                          <EmptySpace min="-2" pref="49" max="-2" attributes="0"/>
                          <Group type="103" groupAlignment="0" max="-2" attributes="0">
                              <Component id="txtuser" alignment="0" pref="124" max="32767" attributes="0"/>
                              <Component id="txtname" alignment="0" pref="124" max="32767" attributes="0"/>
                              <Component id="txtpass" alignment="0" max="32767" attributes="0"/>
                          </Group>
                      </Group>
                      <Group type="102" alignment="1" attributes="0">
                          <Component id="jButton1" min="-2" max="-2" attributes="0"/>
                          <EmptySpace max="-2" attributes="0"/>
                          <Component id="jButton2" min="-2" max="-2" attributes="0"/>
                          <EmptySpace type="unrelated" max="-2" attributes="0"/>
                          <Component id="jButton4" min="-2" max="-2" attributes="0"/>
                      </Group>
                  </Group>
                  <EmptySpace pref="83" max="32767" attributes="0"/>
                  <Component id="jScrollPane1" min="-2" pref="409" max="-2" attributes="0"/>
                  <EmptySpace max="-2" attributes="0"/>
              </Group>
          </Group>
        </DimensionLayout>
        <DimensionLayout dim="1">
          <Group type="103" groupAlignment="0" attributes="0">
              <Group type="102" alignment="0" attributes="0">
                  <EmptySpace min="-2" pref="39" max="-2" attributes="0"/>
                  <Group type="103" groupAlignment="3" attributes="0">
                      <Component id="jLabel6" alignment="3" min="-2" max="-2" attributes="0"/>
                      <Component id="txtname" alignment="3" min="-2" max="-2" attributes="0"/>
                  </Group>
                  <EmptySpace type="separate" max="-2" attributes="0"/>
                  <Group type="103" groupAlignment="3" attributes="0">
                      <Component id="jLabel8" alignment="3" min="-2" max="-2" attributes="0"/>
                      <Component id="txtuser" alignment="3" min="-2" max="-2" attributes="0"/>
                  </Group>
                  <EmptySpace type="separate" max="-2" attributes="0"/>
                  <Group type="103" groupAlignment="3" attributes="0">
                      <Component id="jLabel11" alignment="3" min="-2" max="-2" attributes="0"/>
                      <Component id="txtpass" alignment="3" min="-2" max="-2" attributes="0"/>
                  </Group>
                  <EmptySpace min="-2" pref="96" max="-2" attributes="0"/>
                  <Group type="103" groupAlignment="3" attributes="0">
                      <Component id="jButton2" alignment="3" min="-2" max="-2" attributes="0"/>
                      <Component id="jButton1" alignment="3" min="-2" max="-2" attributes="0"/>
                      <Component id="jButton4" alignment="3" min="-2" max="-2" attributes="0"/>
                  </Group>
                  <EmptySpace pref="19" max="32767" attributes="0"/>
              </Group>
              <Component id="jScrollPane1" alignment="1" pref="273" max="32767" attributes="0"/>
          </Group>
        </DimensionLayout>
      </Layout>
      <SubComponents>
        <Component class="javax.swing.JLabel" name="jLabel6">
          <Properties>
            <Property name="text" type="java.lang.String" value="Name"/>
          </Properties>
        </Component>
        <Component class="javax.swing.JButton" name="jButton1">
          <Properties>
            <Property name="text" type="java.lang.String" value="Add"/>
          </Properties>
          <Events>
            <EventHandler event="actionPerformed" listener="java.awt.event.ActionListener" parameters="java.awt.event.ActionEvent" handler="jButton1ActionPerformed"/>
          </Events>
        </Component>
        <Component class="javax.swing.JTextField" name="txtname">
        </Component>
        <Component class="javax.swing.JButton" name="jButton2">
          <Properties>
            <Property name="text" type="java.lang.String" value="Delete"/>
          </Properties>
          <Events>
            <EventHandler event="actionPerformed" listener="java.awt.event.ActionListener" parameters="java.awt.event.ActionEvent" handler="jButton2ActionPerformed"/>
          </Events>
        </Component>
        <Component class="javax.swing.JLabel" name="jLabel8">
          <Properties>
            <Property name="text" type="java.lang.String" value="Username"/>
          </Properties>
        </Component>
        <Component class="javax.swing.JTextField" name="txtuser">
        </Component>
        <Component class="javax.swing.JLabel" name="jLabel11">
          <Properties>
            <Property name="text" type="java.lang.String" value="Password"/>
          </Properties>
        </Component>
        <Component class="javax.swing.JPasswordField" name="txtpass">
        </Component>
        <Container class="javax.swing.JScrollPane" name="jScrollPane1">
          <AuxValues>
            <AuxValue name="autoScrollPane" type="java.lang.Boolean" value="true"/>
          </AuxValues>

          <Layout class="org.netbeans.modules.form.compat2.layouts.support.JScrollPaneSupportLayout"/>
          <SubComponents>
            <Component class="javax.swing.JTable" name="jTable1">
              <Properties>
                <Property name="border" type="javax.swing.border.Border" editor="org.netbeans.modules.form.editors2.BorderEditor">
                  <Border info="org.netbeans.modules.form.compat2.border.EtchedBorderInfo">
                    <EtchetBorder/>
                  </Border>
                </Property>
                <Property name="model" type="javax.swing.table.TableModel" editor="org.netbeans.modules.form.editors2.TableModelEditor">
                  <Table columnCount="2" rowCount="0">
                    <Column editable="true" title="id" type="java.lang.Object"/>
                    <Column editable="true" title="Username" type="java.lang.Object"/>
                  </Table>
                </Property>
                <Property name="columnModel" type="javax.swing.table.TableColumnModel" editor="org.netbeans.modules.form.editors2.TableColumnModelEditor">
                  <TableColumnModel selectionModel="0">
                    <Column maxWidth="-1" minWidth="-1" prefWidth="-1" resizable="true">
                      <Title/>
                      <Editor/>
                      <Renderer/>
                    </Column>
                    <Column maxWidth="-1" minWidth="-1" prefWidth="-1" resizable="true">
                      <Title/>
                      <Editor/>
                      <Renderer/>
                    </Column>
                  </TableColumnModel>
                </Property>
                <Property name="tableHeader" type="javax.swing.table.JTableHeader" editor="org.netbeans.modules.form.editors2.JTableHeaderEditor">
                  <TableHeader reorderingAllowed="true" resizingAllowed="true"/>
                </Property>
              </Properties>
              <Events>
                <EventHandler event="mouseClicked" listener="java.awt.event.MouseListener" parameters="java.awt.event.MouseEvent" handler="jTable1MouseClicked"/>
              </Events>
            </Component>
          </SubComponents>
        </Container>
        <Component class="javax.swing.JButton" name="jButton4">
          <Properties>
            <Property name="text" type="java.lang.String" value="Cancel"/>
          </Properties>
          <Events>
            <EventHandler event="actionPerformed" listener="java.awt.event.ActionListener" parameters="java.awt.event.ActionEvent" handler="jButton4ActionPerformed"/>
          </Events>
        </Component>
      </SubComponents>
    </Container>
  </SubComponents>
</Form>