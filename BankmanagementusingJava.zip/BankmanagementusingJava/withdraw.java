<?xml version="1.0" encoding="UTF-8" ?>

<Form version="1.3" maxVersion="1.9" type="org.netbeans.modules.form.forminfo.JInternalFrameFormInfo">
  <SyntheticProperties>
    <SyntheticProperty name="formSizePolicy" type="int" value="1"/>
  </SyntheticProperties>
  <AuxValues>
    <AuxValue name="FormSettings_autoResourcing" type="java.lang.Integer" value="0"/>
    <AuxValue name="FormSettings_autoSetComponentName" type="java.lang.Boolean" value="false"/>
    <AuxValue name="FormSettings_generateFQN" type="java.lang.Boolean" value="true"/>
    <AuxValue name="FormSettings_generateMnemonicsCode" type="java.lang.Boolean" value="false"/>
    <AuxValue name="FormSettings_i18nAutoMode" type="java.lang.Boolean" value="false"/>
    <AuxValue name="FormSettings_layoutCodeTarget" type="java.lang.Integer" value="1"/>
    <AuxValue name="FormSettings_listenerGenerationStyle" type="java.lang.Integer" value="0"/>
    <AuxValue name="FormSettings_variablesLocal" type="java.lang.Boolean" value="false"/>
    <AuxValue name="FormSettings_variablesModifier" type="java.lang.Integer" value="2"/>
  </AuxValues>

  <Layout>
    <DimensionLayout dim="0">
      <Group type="103" groupAlignment="0" attributes="0">
          <Group type="102" alignment="0" attributes="0">
              <Group type="103" groupAlignment="0" attributes="0">
                  <Group type="102" alignment="0" attributes="0">
                      <EmptySpace max="-2" attributes="0"/>
                      <Component id="jPanel1" min="-2" max="-2" attributes="0"/>
                  </Group>
                  <Group type="102" alignment="0" attributes="0">
                      <Group type="103" groupAlignment="0" attributes="0">
                          <Group type="102" attributes="0">
                              <EmptySpace min="-2" pref="42" max="-2" attributes="0"/>
                              <Group type="103" groupAlignment="0" attributes="0">
                                  <Component id="jLabel2" alignment="0" min="-2" max="-2" attributes="0"/>
                                  <Component id="jLabel3" alignment="0" min="-2" max="-2" attributes="0"/>
                                  <Component id="jLabel8" alignment="0" min="-2" max="-2" attributes="0"/>
                              </Group>
                              <EmptySpace min="-2" pref="31" max="-2" attributes="0"/>
                          </Group>
                          <Group type="102" alignment="1" attributes="0">
                              <EmptySpace max="-2" attributes="0"/>
                              <Component id="jLabel9" min="-2" max="-2" attributes="0"/>
                              <EmptySpace type="separate" max="-2" attributes="0"/>
                          </Group>
                      </Group>
                      <Group type="103" groupAlignment="0" attributes="0">
                          <Component id="jLabel6" min="-2" max="-2" attributes="0"/>
                          <Component id="txtlame" min="-2" pref="156" max="-2" attributes="0"/>
                          <Component id="txtfname" min="-2" pref="156" max="-2" attributes="0"/>
                          <Component id="jLabel7" min="-2" max="-2" attributes="0"/>
                      </Group>
                  </Group>
              </Group>
              <Group type="103" groupAlignment="0" attributes="0">
                  <Group type="102" attributes="0">
                      <Group type="103" groupAlignment="0" attributes="0">
                          <Group type="102" alignment="0" attributes="0">
                              <EmptySpace min="-2" pref="82" max="-2" attributes="0"/>
                              <Component id="jLabel4" min="-2" max="-2" attributes="0"/>
                          </Group>
                          <Group type="102" alignment="0" attributes="0">
                              <EmptySpace min="-2" pref="120" max="-2" attributes="0"/>
                              <Component id="jLabel5" min="-2" max="-2" attributes="0"/>
                          </Group>
                          <Group type="102" alignment="0" attributes="0">
                              <EmptySpace min="-2" pref="60" max="-2" attributes="0"/>
                              <Component id="lbal" min="-2" max="-2" attributes="0"/>
                          </Group>
                      </Group>
                      <EmptySpace max="32767" attributes="0"/>
                  </Group>
                  <Group type="102" alignment="1" attributes="0">
                      <EmptySpace pref="77" max="32767" attributes="0"/>
                      <Group type="103" groupAlignment="0" attributes="0">
                          <Component id="amount" alignment="0" min="-2" pref="158" max="-2" attributes="0"/>
                          <Group type="102" alignment="0" attributes="0">
                              <Component id="jButton2" min="-2" pref="89" max="-2" attributes="0"/>
                              <EmptySpace type="separate" max="-2" attributes="0"/>
                              <Component id="jButton3" min="-2" pref="82" max="-2" attributes="0"/>
                          </Group>
                      </Group>
                      <EmptySpace min="-2" pref="36" max="-2" attributes="0"/>
                  </Group>
              </Group>
          </Group>
      </Group>
    </DimensionLayout>
    <DimensionLayout dim="1">
      <Group type="103" groupAlignment="0" attributes="0">
          <Group type="102" alignment="1" attributes="0">
              <Group type="103" groupAlignment="0" attributes="0">
                  <Group type="102" attributes="0">
                      <Group type="103" groupAlignment="0" attributes="0">
                          <Group type="102" alignment="0" attributes="0">
                              <EmptySpace min="-2" pref="39" max="-2" attributes="0"/>
                              <Component id="jLabel4" min="-2" max="-2" attributes="0"/>
                              <EmptySpace min="-2" pref="34" max="-2" attributes="0"/>
                              <Component id="lbal" min="-2" max="-2" attributes="0"/>
                          </Group>
                          <Group type="102" alignment="0" attributes="0">
                              <EmptySpace max="-2" attributes="0"/>
                              <Component id="jPanel1" min="-2" max="-2" attributes="0"/>
                          </Group>
                      </Group>
                      <EmptySpace type="unrelated" max="-2" attributes="0"/>
                      <Group type="103" groupAlignment="3" attributes="0">
                          <Component id="jLabel7" alignment="3" min="-2" max="-2" attributes="0"/>
                          <Component id="jLabel9" alignment="3" min="-2" max="-2" attributes="0"/>
                      </Group>
                      <EmptySpace max="-2" attributes="0"/>
                  </Group>
                  <Group type="102" alignment="1" attributes="0">
                      <Component id="jLabel5" min="-2" max="-2" attributes="0"/>
                      <EmptySpace min="-2" pref="14" max="-2" attributes="0"/>
                  </Group>
              </Group>
              <Group type="103" groupAlignment="0" attributes="0">
                  <Component id="amount" alignment="0" min="-2" pref="54" max="-2" attributes="0"/>
                  <Group type="103" alignment="1" groupAlignment="3" attributes="0">
                      <Component id="txtfname" alignment="3" min="-2" max="-2" attributes="0"/>
                      <Component id="jLabel2" alignment="3" min="-2" max="-2" attributes="0"/>
                  </Group>
              </Group>
              <EmptySpace min="-2" pref="24" max="-2" attributes="0"/>
              <Group type="103" groupAlignment="3" attributes="0">
                  <Component id="txtlame" alignment="3" min="-2" max="-2" attributes="0"/>
                  <Component id="jLabel3" alignment="3" min="-2" max="-2" attributes="0"/>
              </Group>
              <Group type="103" groupAlignment="0" attributes="0">
                  <Group type="102" attributes="0">
                      <EmptySpace max="32767" attributes="0"/>
                      <Group type="103" groupAlignment="3" attributes="0">
                          <Component id="jButton2" alignment="3" min="-2" pref="35" max="-2" attributes="0"/>
                          <Component id="jButton3" alignment="3" min="-2" pref="35" max="-2" attributes="0"/>
                      </Group>
                      <EmptySpace min="-2" pref="47" max="-2" attributes="0"/>
                  </Group>
                  <Group type="102" alignment="0" attributes="0">
                      <EmptySpace min="-2" pref="33" max="-2" attributes="0"/>
                      <Group type="103" groupAlignment="3" attributes="0">
                          <Component id="jLabel8" alignment="3" min="-2" max="-2" attributes="0"/>
                          <Component id="jLabel6" alignment="3" min="-2" pref="14" max="-2" attributes="0"/>
                      </Group>
                      <EmptySpace max="32767" attributes="0"/>
                  </Group>
              </Group>
          </Group>
      </Group>
    </DimensionLayout>
  </Layout>
  <SubComponents>
    <Component class="javax.swing.JLabel" name="jLabel4">
      <Properties>
        <Property name="font" type="java.awt.Font" editor="org.netbeans.beaninfo.editors.FontEditor">
          <Font name="Tahoma" size="12" style="1"/>
        </Property>
        <Property name="text" type="java.lang.String" value="Balance"/>
      </Properties>
    </Component>
    <Component class="javax.swing.JLabel" name="lbal">
      <Properties>
        <Property name="font" type="java.awt.Font" editor="org.netbeans.beaninfo.editors.FontEditor">
          <Font name="Tahoma" size="24" style="1"/>
        </Property>
        <Property name="foreground" type="java.awt.Color" editor="org.netbeans.beaninfo.editors.ColorEditor">
          <Color blue="cc" green="33" red="0" type="rgb"/>
        </Property>
        <Property name="text" type="java.lang.String" value="Balance"/>
      </Properties>
    </Component>
    <Component class="javax.swing.JLabel" name="jLabel2">
      <Properties>
        <Property name="text" type="java.lang.String" value="Firstname"/>
      </Properties>
    </Component>
    <Component class="javax.swing.JLabel" name="jLabel3">
      <Properties>
        <Property name="text" type="java.lang.String" value="Lastname"/>
      </Properties>
    </Component>
    <Container class="javax.swing.JPanel" name="jPanel1">
      <Properties>
        <Property name="border" type="javax.swing.border.Border" editor="org.netbeans.modules.form.editors2.BorderEditor">
          <Border info="org.netbeans.modules.form.compat2.border.TitledBorderInfo">
            <TitledBorder title="Account No"/>
          </Border>
        </Property>
      </Properties>

      <Layout>
        <DimensionLayout dim="0">
          <Group type="103" groupAlignment="0" attributes="0">
              <Group type="102" alignment="0" attributes="0">
                  <Group type="103" groupAlignment="0" attributes="0">
                      <Group type="102" alignment="0" attributes="0">
                          <Group type="103" groupAlignment="0" attributes="0">
                              <Group type="102" alignment="0" attributes="0">
                                  <EmptySpace min="-2" pref="43" max="-2" attributes="0"/>
                                  <Component id="jLabel1" min="-2" max="-2" attributes="0"/>
                              </Group>
                              <Group type="102" alignment="0" attributes="0">
                                  <EmptySpace max="-2" attributes="0"/>
                                  <Component id="txtaccno" min="-2" pref="239" max="-2" attributes="0"/>
                              </Group>
                          </Group>
                          <EmptySpace min="0" pref="12" max="32767" attributes="0"/>
                      </Group>
                      <Group type="102" alignment="1" attributes="0">
                          <EmptySpace min="0" pref="0" max="32767" attributes="0"/>
                          <Component id="jButton1" min="-2" max="-2" attributes="0"/>
                      </Group>
                  </Group>
                  <EmptySpace max="-2" attributes="0"/>
              </Group>
          </Group>
        </DimensionLayout>
        <DimensionLayout dim="1">
          <Group type="103" groupAlignment="0" attributes="0">
              <Group type="102" alignment="0" attributes="0">
                  <EmptySpace max="-2" attributes="0"/>
                  <Component id="jLabel1" min="-2" max="-2" attributes="0"/>
                  <EmptySpace type="separate" max="-2" attributes="0"/>
                  <Component id="txtaccno" min="-2" max="-2" attributes="0"/>
                  <EmptySpace pref="18" max="32767" attributes="0"/>
                  <Component id="jButton1" min="-2" max="-2" attributes="0"/>
              </Group>
          </Group>
        </DimensionLayout>
      </Layout>
      <SubComponents>
        <Component class="javax.swing.JLabel" name="jLabel1">
          <Properties>
            <Property name="font" type="java.awt.Font" editor="org.netbeans.beaninfo.editors.FontEditor">
              <Font name="Tahoma" size="14" style="1"/>
            </Property>
            <Property name="text" type="java.lang.String" value="Enter the Acccount No"/>
          </Properties>
        </Component>
        <Component class="javax.swing.JTextField" name="txtaccno">
        </Component>
        <Component class="javax.swing.JButton" name="jButton1">
          <Properties>
            <Property name="text" type="java.lang.String" value="Find"/>
          </Properties>
          <Events>
            <EventHandler event="actionPerformed" listener="java.awt.event.ActionListener" parameters="java.awt.event.ActionEvent" handler="jButton1ActionPerformed"/>
          </Events>
        </Component>
      </SubComponents>
    </Container>
    <Component class="javax.swing.JTextField" name="txtfname">
    </Component>
    <Component class="javax.swing.JTextField" name="txtlame">
    </Component>
    <Component class="javax.swing.JLabel" name="jLabel5">
      <Properties>
        <Property name="font" type="java.awt.Font" editor="org.netbeans.beaninfo.editors.FontEditor">
          <Font name="Tahoma" size="12" style="1"/>
        </Property>
        <Property name="text" type="java.lang.String" value="Withdraw"/>
      </Properties>
    </Component>
    <Component class="javax.swing.JTextField" name="amount">
      <Properties>
        <Property name="background" type="java.awt.Color" editor="org.netbeans.beaninfo.editors.ColorEditor">
          <Color blue="cc" green="cc" red="0" type="rgb"/>
        </Property>
        <Property name="font" type="java.awt.Font" editor="org.netbeans.beaninfo.editors.FontEditor">
          <Font name="Tahoma" size="24" style="1"/>
        </Property>
        <Property name="foreground" type="java.awt.Color" editor="org.netbeans.beaninfo.editors.ColorEditor">
          <Color blue="ff" green="ff" red="ff" type="rgb"/>
        </Property>
      </Properties>
    </Component>
    <Component class="javax.swing.JButton" name="jButton2">
      <Properties>
        <Property name="text" type="java.lang.String" value="OK"/>
      </Properties>
      <Events>
        <EventHandler event="actionPerformed" listener="java.awt.event.ActionListener" parameters="java.awt.event.ActionEvent" handler="jButton2ActionPerformed"/>
      </Events>
    </Component>
    <Component class="javax.swing.JLabel" name="jLabel6">
      <Properties>
        <Property name="font" type="java.awt.Font" editor="org.netbeans.beaninfo.editors.FontEditor">
          <Font name="Tahoma" size="18" style="1"/>
        </Property>
        <Property name="text" type="java.lang.String" value="jLabel6"/>
      </Properties>
    </Component>
    <Component class="javax.swing.JLabel" name="jLabel7">
      <Properties>
        <Property name="font" type="java.awt.Font" editor="org.netbeans.beaninfo.editors.FontEditor">
          <Font name="Tahoma" size="18" style="1"/>
        </Property>
        <Property name="text" type="java.lang.String" value="jLabel7"/>
      </Properties>
    </Component>
    <Component class="javax.swing.JButton" name="jButton3">
      <Properties>
        <Property name="text" type="java.lang.String" value="Cancel"/>
      </Properties>
      <Events>
        <EventHandler event="actionPerformed" listener="java.awt.event.ActionListener" parameters="java.awt.event.ActionEvent" handler="jButton3ActionPerformed"/>
      </Events>
    </Component>
    <Component class="javax.swing.JLabel" name="jLabel8">
      <Properties>
        <Property name="text" type="java.lang.String" value="Date"/>
      </Properties>
    </Component>
    <Component class="javax.swing.JLabel" name="jLabel9">
      <Properties>
        <Property name="text" type="java.lang.String" value="Customer ID"/>
      </Properties>
    </Component>
  </SubComponents>
</Form>